package article.service;

public interface Constants {
    String SERVICE_BASE_URL = "http://localhost:8080/articles/rest/articles";

}
